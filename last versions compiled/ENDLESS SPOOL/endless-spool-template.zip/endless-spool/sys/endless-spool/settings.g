; ============================================================================
; Endless spool – settings  (0:/sys/endless-spool/settings.g)
; Called from config.g with:  M98 P"endless-spool/settings.g"
; EDIT THE VALUES BELOW FOR YOUR PRINTER.
; ============================================================================

; Master switch: false = normal pause on runout, as without this template
var enabled = true

; Backup lane for each extruder drive, indexed by drive number.
; Example for 3 drives: drive 0 -> 1, drive 1 -> 2, drive 2 -> 0. Use -1 for "no backup".
var backup = {1, 2, 0}

; Home drive of each tool, indexed by tool number (what your M563 lines in config.g use).
; reset.g puts the tools back to these drives after a print.
var homeDrive = {0, 1, 2}

; Filament path (mm)
var unloadDist = 600      ; pull the empty lane back this far: must clear the splitter/merge point
var loadDist   = 580      ; fast load of the backup lane: from its drive to just before the nozzle
var purgeDist  = 40       ; slow purge after loading
var unloadFeed = 3000     ; mm/min
var loadFeed   = 3000     ; mm/min
var purgeFeed  = 150      ; mm/min

; Where to wait while swapping (machine coordinates, G53) and how far to lift Z first
var parkX = 10
var parkY = 10
var zLift = 5
var travelFeed = 9000     ; mm/min

; ---------------------------------------------------------------------------
; Nothing to edit below this line
; ---------------------------------------------------------------------------
if !exists(global.esEnabled)
	global esEnabled = var.enabled
	global esBackup = var.backup
	global esHomeDrive = var.homeDrive
	global esUnloadDist = var.unloadDist
	global esLoadDist = var.loadDist
	global esPurgeDist = var.purgeDist
	global esUnloadFeed = var.unloadFeed
	global esLoadFeed = var.loadFeed
	global esPurgeFeed = var.purgeFeed
	global esParkX = var.parkX
	global esParkY = var.parkY
	global esZLift = var.zLift
	global esTravelFeed = var.travelFeed
	global esSwaps = 0
else
	set global.esEnabled = var.enabled
	set global.esBackup = var.backup
	set global.esHomeDrive = var.homeDrive
	set global.esUnloadDist = var.unloadDist
	set global.esLoadDist = var.loadDist
	set global.esPurgeDist = var.purgeDist
	set global.esUnloadFeed = var.unloadFeed
	set global.esLoadFeed = var.loadFeed
	set global.esPurgeFeed = var.purgeFeed
	set global.esParkX = var.parkX
	set global.esParkY = var.parkY
	set global.esZLift = var.zLift
	set global.esTravelFeed = var.travelFeed
	set global.esSwaps = 0
