; ============================================================================
; Endless spool – swap.g  (0:/sys/endless-spool/swap.g)
; Called by filament-error.g:  M98 P"endless-spool/swap.g" T<tool> O<old drive> N<new drive>
; Moves tool T from drive O to drive N and continues where the print stopped.
; Movement and extrusion modes are restored by RRF when this macro ends.
; ============================================================================

var t = param.T
var oldDrive = param.O
var newDrive = param.N

echo "Endless spool: T" ^ var.t ^ " extruder " ^ var.oldDrive ^ " ran out, switching to " ^ var.newDrive

; Remember the tool's settings before it is redefined (M563 replaces the tool)
var name = tools[var.t].name
var heater = tools[var.t].heaters[0]
var activeTemp = tools[var.t].active[0]
var standbyTemp = tools[var.t].standby[0]
var offX = tools[var.t].offsets[0]
var offY = tools[var.t].offsets[1]
var offZ = tools[var.t].offsets[2]
var hasFan = #tools[var.t].fans > 0
var fan = -1
if var.hasFan
	set var.fan = tools[var.t].fans[0]
var pa = move.extruders[var.oldDrive].pressureAdvance
var factor = move.extruders[var.oldDrive].factor

; 1. Save the position (restore point 5) and park
G60 S5
M83
G91
G1 Z{global.esZLift} F{global.esTravelFeed}
G90
G1 X{global.esParkX} Y{global.esParkY} F{global.esTravelFeed}
M400

; 2. Pull the empty lane back past the merge point (the tool still drives the old lane)
G1 E{-global.esUnloadDist} F{global.esUnloadFeed}
M400

; 3. Point the tool at the backup lane. Deselect and reselect with P0, so no tool change macros run.
T-1 P0
if var.hasFan
	M563 P{var.t} D{var.newDrive} H{var.heater} F{var.fan} S{var.name}
else
	M563 P{var.t} D{var.newDrive} H{var.heater} S{var.name}
G10 P{var.t} X{var.offX} Y{var.offY} Z{var.offZ}
M568 P{var.t} S{var.activeTemp} R{var.standbyTemp}
M572 D{var.newDrive} S{var.pa}
M221 D{var.newDrive} S{var.factor * 100}
T{var.t} P0
M116 P{var.t}                          ; wait for the temperature (it should already be there)

; 4. Load the backup lane and purge
G1 E{global.esLoadDist} F{global.esLoadFeed}
G1 E{global.esPurgeDist} F{global.esPurgeFeed}
M400
; >>> optional: wipe the nozzle here (brush, purge bucket wiper ...)

; 5. Back to the print: XY at the lifted height first, then Z
G1 R5 X0 Y0 Z{global.esZLift} F{global.esTravelFeed}
G1 R5 X0 Y0 Z0 F{global.esTravelFeed}

set global.esSwaps = global.esSwaps + 1
M291 P{"T" ^ var.t ^ " continues on extruder " ^ var.newDrive ^ " (extruder " ^ var.oldDrive ^ " ran out)."} R"Endless spool" S1 T10
