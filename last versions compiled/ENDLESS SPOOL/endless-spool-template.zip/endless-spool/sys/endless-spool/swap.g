; ============================================================================
; Endless spool – swap.g  (0:/sys/endless-spool/swap.g)
; Called by filament-error.g:  M98 P"endless-spool/swap.g" T<tool> O<old drive> N<new drive>
; Moves tool T from drive O to drive N and continues where the print stopped.
; RRF restores the movement/extrusion modes and the feed rate when this macro ends.
; ============================================================================

var t = param.T
var oldDrive = param.O
var newDrive = param.N

echo "Endless spool: T" ^ var.t ^ " extruder " ^ var.oldDrive ^ " ran out, switching to " ^ var.newDrive

; Settings that belong to the extruder drive, not to the tool
var pa = move.extruders[var.oldDrive].pressureAdvance
var factor = move.extruders[var.oldDrive].factor
; The print's extruder position: the moves below must not change it (matters for absolute extrusion, M82)
var ePos = move.virtualEPos

; 1. Save the position (restore point 5), retract a little, lift Z (not above the axis maximum) and park
G60 S5
M83
G1 E-2 F2400
G90
G1 Z{min(move.axes[2].userPosition + global.esZLift, move.axes[2].max)} F{global.esTravelFeed}
G53 G1 X{global.esParkX} Y{global.esParkY} F{global.esTravelFeed}
M400

; 2. Pull the empty lane back past the merge point (the tool still drives the old lane)
G1 E{-global.esUnloadDist} F{global.esUnloadFeed}
M400

; 3. Point the tool at the backup lane. Deselect and reselect with P0, so no tool change macros run.
T-1 P0
M98 P"endless-spool/retarget.g" T{var.t} D{var.newDrive}
M572 D{var.newDrive} S{var.pa}
M221 D{var.newDrive} S{var.factor * 100}
T{var.t} P0
M116 P{var.t}                          ; wait for the temperature (normally already there)

; 4. Load the backup lane and purge
M83
G1 E{global.esLoadDist} F{global.esLoadFeed}
G1 E{global.esPurgeDist} F{global.esPurgeFeed}
G1 E-2 F2400
M400
; >>> optional: wipe the nozzle here (brush, purge bucket wiper ...)

; 5. Back to the print: XY at the lifted height, then down, then undo the small retraction
G1 R5 X0 Y0 F{global.esTravelFeed}
G1 R5 Z0 F{global.esTravelFeed}
G1 E2 F2400
M400

G92 E{var.ePos}
set global.esSwaps = global.esSwaps + 1
M291 P{"T" ^ var.t ^ " continues on extruder " ^ var.newDrive ^ " (extruder " ^ var.oldDrive ^ " ran out)."} R"Endless spool" S1 T10
