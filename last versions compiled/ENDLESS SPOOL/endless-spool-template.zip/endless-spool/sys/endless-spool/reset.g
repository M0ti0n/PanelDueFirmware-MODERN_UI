; ============================================================================
; Endless spool – reset.g  (0:/sys/endless-spool/reset.g)
; Puts every tool back on its home drive (global.esHomeDrive).
; Call it from stop.g and cancel.g:   M98 P"endless-spool/reset.g"
; ============================================================================

if !exists(global.esHomeDrive)
	M99

var wasTool = state.currentTool
var changed = false

while iterations < #global.esHomeDrive && iterations < #tools
	if tools[iterations] != null && #tools[iterations].extruders > 0 && tools[iterations].extruders[0] != global.esHomeDrive[iterations] && global.esHomeDrive[iterations] >= 0
		if !var.changed
			T-1 P0
			set var.changed = true
		M98 P"endless-spool/retarget.g" T{iterations} D{global.esHomeDrive[iterations]}
		echo "Endless spool: T" ^ iterations ^ " is back on extruder " ^ global.esHomeDrive[iterations]

if var.changed && var.wasTool >= 0
	T{var.wasTool} P0

set global.esSwaps = 0
