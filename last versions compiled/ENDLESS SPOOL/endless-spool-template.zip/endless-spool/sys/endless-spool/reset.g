; ============================================================================
; Endless spool – reset.g  (0:/sys/endless-spool/reset.g)
; Puts every tool back on its home drive (global.esHomeDrive).
; Call it from stop.g and cancel.g:   M98 P"endless-spool/reset.g"
; ============================================================================

if !exists(global.esHomeDrive)
	M99

var wasTool = state.currentTool
T-1 P0

while iterations < #global.esHomeDrive && iterations < #tools
	var t = iterations
	if tools[var.t] != null && #tools[var.t].extruders > 0 && tools[var.t].extruders[0] != global.esHomeDrive[var.t]
		var name = tools[var.t].name
		var heater = tools[var.t].heaters[0]
		var activeTemp = tools[var.t].active[0]
		var standbyTemp = tools[var.t].standby[0]
		var offX = tools[var.t].offsets[0]
		var offY = tools[var.t].offsets[1]
		var offZ = tools[var.t].offsets[2]
		if #tools[var.t].fans > 0
			M563 P{var.t} D{global.esHomeDrive[var.t]} H{var.heater} F{tools[var.t].fans[0]} S{var.name}
		else
			M563 P{var.t} D{global.esHomeDrive[var.t]} H{var.heater} S{var.name}
		G10 P{var.t} X{var.offX} Y{var.offY} Z{var.offZ}
		M568 P{var.t} S{var.activeTemp} R{var.standbyTemp}
		echo "Endless spool: T" ^ var.t ^ " is back on extruder " ^ global.esHomeDrive[var.t]

if var.wasTool >= 0
	T{var.wasTool} P0

set global.esSwaps = 0
