; ============================================================================
; Endless spool – retarget.g  (0:/sys/endless-spool/retarget.g)
;   M98 P"endless-spool/retarget.g" T<tool> D<drive>
; Points tool T at extruder drive D. M563 replaces the whole tool, so everything the
; tool had is read first and set again: heater, part cooling fan, name, XYZ offsets,
; active/standby temperatures and firmware retraction (M207).
; The tool must NOT be selected when this runs (callers use T-1 P0 first).
; ============================================================================

var t = param.T
var d = param.D

var name = tools[var.t].name
var heater = (#tools[var.t].heaters > 0) ? tools[var.t].heaters[0] : -1
var fan = (#tools[var.t].fans > 0) ? tools[var.t].fans[0] : -1
var activeTemp = (#tools[var.t].active > 0) ? tools[var.t].active[0] : 0
var standbyTemp = (#tools[var.t].standby > 0) ? tools[var.t].standby[0] : 0
var offX = tools[var.t].offsets[0]
var offY = tools[var.t].offsets[1]
var offZ = tools[var.t].offsets[2]

var hasRetraction = exists(tools[var.t].retraction)
var rLength = 0
var rExtra = 0
var rSpeed = 0
var rUnSpeed = 0
var rZHop = 0
if var.hasRetraction
	set var.rLength = tools[var.t].retraction.length
	set var.rExtra = tools[var.t].retraction.extraRestart
	set var.rSpeed = tools[var.t].retraction.speed
	set var.rUnSpeed = tools[var.t].retraction.unretractSpeed
	set var.rZHop = tools[var.t].retraction.zHop

if var.heater >= 0 && var.fan >= 0
	M563 P{var.t} D{var.d} H{var.heater} F{var.fan} S{var.name}
elif var.heater >= 0
	M563 P{var.t} D{var.d} H{var.heater} S{var.name}
elif var.fan >= 0
	M563 P{var.t} D{var.d} F{var.fan} S{var.name}
else
	M563 P{var.t} D{var.d} S{var.name}

G10 P{var.t} X{var.offX} Y{var.offY} Z{var.offZ}
if var.heater >= 0
	M568 P{var.t} S{var.activeTemp} R{var.standbyTemp}
if var.hasRetraction
	M207 P{var.t} S{var.rLength} R{var.rExtra} F{var.rSpeed * 60} T{var.rUnSpeed * 60} Z{var.rZHop}
