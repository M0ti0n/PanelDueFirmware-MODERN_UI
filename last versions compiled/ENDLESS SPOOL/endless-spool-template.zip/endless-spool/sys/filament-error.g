; ============================================================================
; Endless spool – filament-error.g  (0:/sys/filament-error.g)
; RRF 3.4+ runs this when a filament monitor reports a problem, WITHOUT pausing.
; Parameter from RRF: D = extruder drive number
; Swaps only on a real runout ("noFilament"). Any other monitor problem (too little
; movement = possible jam or clog, sensor error, ...) pauses the print as usual.
; ============================================================================

; Not printing (e.g. already paused): only report
if state.status != "processing"
	M291 P{"Filament problem on extruder " ^ (exists(param.D) ? param.D : -1) ^ "."} R"Filament" S1 T0
	M99

; Not set up, switched off, or no extruder number: pause like RRF without this file
if !exists(param.D) || !exists(global.esEnabled) || !global.esEnabled
	M25
	M291 P{"Filament problem on extruder " ^ (exists(param.D) ? param.D : -1) ^ ". Print paused."} R"Filament" S1 T0
	M99

var drive = param.D

; Only a real runout is swapped
if var.drive >= #sensors.filamentMonitors || sensors.filamentMonitors[var.drive] == null || sensors.filamentMonitors[var.drive].status != "noFilament"
	M25
	M291 P{"Filament monitor problem on extruder " ^ var.drive ^ " (not a runout). Print paused."} R"Filament" S1 T0
	M99

; Only the drive of the active tool can be swapped while printing
var tool = state.currentTool
if var.tool < 0 || #tools[var.tool].extruders == 0 || tools[var.tool].extruders[0] != var.drive
	M25
	M291 P{"Extruder " ^ var.drive ^ " ran out, but it is not the active tool's drive. Print paused."} R"Endless spool" S1 T0
	M99

; Backup lane for this drive
var newDrive = -1
if var.drive < #global.esBackup
	set var.newDrive = global.esBackup[var.drive]

; No backup, backup out of range, or more swaps than there are drives (all lanes used up): pause
if var.newDrive < 0 || var.newDrive >= #move.extruders || var.newDrive == var.drive || global.esSwaps >= #move.extruders
	M25
	M291 P{"Extruder " ^ var.drive ^ " ran out and no backup lane is available. Print paused."} R"Endless spool" S1 T0
	M99

; If the backup lane has its own filament monitor, it must report filament
if var.newDrive < #sensors.filamentMonitors && sensors.filamentMonitors[var.newDrive] != null
	if sensors.filamentMonitors[var.newDrive].status != "ok"
		M25
		M291 P{"Extruder " ^ var.drive ^ " ran out, backup lane " ^ var.newDrive ^ " has no filament. Print paused."} R"Endless spool" S1 T0
		M99

M98 P"endless-spool/swap.g" T{var.tool} O{var.drive} N{var.newDrive}
